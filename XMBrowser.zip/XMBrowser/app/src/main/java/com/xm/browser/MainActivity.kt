package com.xm.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private lateinit var webViewContainer: FrameLayout
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnBookmarks: ImageButton
    private lateinit var btnTabs: ImageButton
    private lateinit var btnNewTab: ImageButton
    private lateinit var btnDarkMode: ImageButton

    private lateinit var bookmarkManager: BookmarkManager
    private val tabs = mutableListOf<Tab>()
    private var currentTabIndex = -1

    private val prefs by lazy { getSharedPreferences("xm_browser_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        // اعمال حالت تاریک ذخیره‌شده قبل از ساخت رابط کاربری
        val isDark = getSharedPreferences("xm_browser_prefs", MODE_PRIVATE).getBoolean("dark_mode", false)
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bookmarkManager = BookmarkManager(this)

        webViewContainer = findViewById(R.id.webViewContainer)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnBookmarks = findViewById(R.id.btnBookmarks)
        btnTabs = findViewById(R.id.btnTabs)
        btnNewTab = findViewById(R.id.btnNewTab)
        btnDarkMode = findViewById(R.id.btnDarkMode)

        setupListeners()
        createNewTab(HOME_URL)
    }

    private fun setupListeners() {
        addressBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                loadInput(addressBar.text.toString())
                true
            } else false
        }

        btnBack.setOnClickListener { currentWebView()?.let { if (it.canGoBack()) it.goBack() } }
        btnForward.setOnClickListener { currentWebView()?.let { if (it.canGoForward()) it.goForward() } }
        btnRefresh.setOnClickListener { currentWebView()?.reload() }
        btnHome.setOnClickListener { currentWebView()?.loadUrl(HOME_URL) }
        btnBookmarks.setOnClickListener { showBookmarksDialog() }
        btnTabs.setOnClickListener { showTabsDialog() }
        btnNewTab.setOnClickListener { createNewTab(HOME_URL) }
        btnDarkMode.setOnClickListener { toggleDarkMode() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createNewTab(url: String) {
        val webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        configureWebView(webView)

        val tab = Tab(webView)
        tabs.add(tab)
        webViewContainer.addView(webView)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                if (!u.startsWith("http://") && !u.startsWith("https://")) {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, request.url))
                        true
                    } catch (e: Exception) {
                        true
                    }
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                tab.url = url
                tab.title = view.title ?: url
                if (isCurrentTab(tab)) {
                    addressBar.setText(url)
                    updateNavButtons()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (isCurrentTab(tab)) {
                    progressBar.progress = newProgress
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                tab.title = title ?: tab.url
            }
        }

        webView.loadUrl(url)
        switchToTab(tabs.size - 1)
    }

    private fun configureWebView(webView: WebView) {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = WebSettings.LOAD_DEFAULT
        applyWebViewDarkMode(webView)
    }

    private fun applyWebViewDarkMode(webView: WebView) {
        val isDark = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, isDark)
        }
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        for (i in tabs.indices) {
            tabs[i].webView.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        val tab = tabs[index]
        addressBar.setText(tab.url)
        title = tab.title
        updateNavButtons()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        webViewContainer.removeView(tab.webView)
        tab.webView.destroy()
        tabs.removeAt(index)

        if (tabs.isEmpty()) {
            createNewTab(HOME_URL)
        } else {
            val newIndex = if (index >= tabs.size) tabs.size - 1 else index
            switchToTab(newIndex)
        }
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(currentTabIndex)?.webView
    private fun isCurrentTab(tab: Tab): Boolean = tabs.getOrNull(currentTabIndex) === tab

    private fun updateNavButtons() {
        val wv = currentWebView()
        btnBack.isEnabled = wv?.canGoBack() ?: false
        btnForward.isEnabled = wv?.canGoForward() ?: false
    }

    private fun loadInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return
        val url = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${Uri.encode(trimmed)}"
        }
        currentWebView()?.loadUrl(url)
    }

    private fun toggleDarkMode() {
        val isDark = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        val newMode = if (isDark) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putBoolean("dark_mode", !isDark).apply()
        AppCompatDelegate.setDefaultNightMode(newMode)
        // برنامه برای اعمال کامل تم دوباره ساخته می‌شود
        recreate()
    }

    private fun showBookmarksDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        val titleView = view.findViewById<TextView>(R.id.dialogTitle)
        val recyclerView = view.findViewById<RecyclerView>(R.id.dialogList)
        val emptyView = view.findViewById<TextView>(R.id.dialogEmpty)
        val addButton = view.findViewById<Button>(R.id.dialogActionButton)

        titleView.text = getString(R.string.bookmarks)
        addButton.visibility = View.VISIBLE
        addButton.text = getString(R.string.add_current_page)

        val dialog = AlertDialog.Builder(this).setView(view).create()

        fun refresh() {
            val bookmarks = bookmarkManager.getAll()
            emptyView.visibility = if (bookmarks.isEmpty()) View.VISIBLE else View.GONE
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = BookmarkAdapter(bookmarks,
                onOpen = { bookmark ->
                    currentWebView()?.loadUrl(bookmark.url)
                    dialog.dismiss()
                },
                onDelete = { bookmark ->
                    bookmarkManager.remove(bookmark.url)
                    refresh()
                })
        }

        addButton.setOnClickListener {
            val tab = tabs.getOrNull(currentTabIndex)
            if (tab != null && tab.url.isNotBlank()) {
                bookmarkManager.add(tab.title.ifBlank { tab.url }, tab.url)
                refresh()
            }
        }

        refresh()
        dialog.show()
    }

    private fun showTabsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        val titleView = view.findViewById<TextView>(R.id.dialogTitle)
        val recyclerView = view.findViewById<RecyclerView>(R.id.dialogList)
        val emptyView = view.findViewById<TextView>(R.id.dialogEmpty)
        val addButton = view.findViewById<Button>(R.id.dialogActionButton)

        titleView.text = getString(R.string.tabs)
        addButton.visibility = View.VISIBLE
        addButton.text = getString(R.string.new_tab)
        emptyView.visibility = View.GONE

        val dialog = AlertDialog.Builder(this).setView(view).create()

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = TabAdapter(tabs,
            onSelect = { index ->
                switchToTab(index)
                dialog.dismiss()
            },
            onClose = { index ->
                closeTab(index)
                recyclerView.adapter?.notifyDataSetChanged()
                if (tabs.isEmpty()) dialog.dismiss()
            })

        addButton.setOnClickListener {
            createNewTab(HOME_URL)
            dialog.dismiss()
        }

        dialog.show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val wv = currentWebView()
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }

    companion object {
        private const val HOME_URL = "file:///android_asset/home.html"
    }
}
