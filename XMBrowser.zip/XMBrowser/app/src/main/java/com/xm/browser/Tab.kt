package com.xm.browser

import android.webkit.WebView

data class Tab(
    val webView: WebView,
    var title: String = "تب جدید",
    var url: String = ""
)
