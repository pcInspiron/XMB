package com.xm.browser

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.widget.Toast

object DownloadHelper {

    fun download(context: Context, url: String, fileName: String, userAgent: String? = null) {
        try {
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(fileName)
                setDescription("در حال دانلود...")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "XMBrowser/$fileName")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)

                // افزودن هدرها برای دور زدن محدودیت دانلود
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrBlank()) {
                    addRequestHeader("Cookie", cookies)
                }
                if (!userAgent.isNullOrBlank()) {
                    addRequestHeader("User-Agent", userAgent)
                }
                addRequestHeader("Referer", url)
            }

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "✅ دانلود شروع شد: $fileName", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(context, "❌ خطا در دانلود: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
