package com.xm.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.mozilla.geckoview.*
import org.mozilla.geckoview.GeckoSession.ContentDelegate
import org.mozilla.geckoview.GeckoSession.NavigationDelegate

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────
    private lateinit var geckoContainer: FrameLayout
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnBookmarks: ImageButton
    private lateinit var btnTabs: ImageButton
    private lateinit var btnNewTab: ImageButton
    private lateinit var btnDarkMode: ImageButton
    private lateinit var btnDownloadVideo: ImageButton
    private lateinit var tvStatus: TextView

    // ── Browser State ──────────────────────────────────────────
    private lateinit var runtime: GeckoRuntime
    private lateinit var bookmarkManager: BookmarkManager

    data class BrowserTab(
        val session: GeckoSession,
        val view: GeckoView,
        var title: String = "تب جدید",
        var url: String = "",
        var canGoBack: Boolean = false,
        var canGoForward: Boolean = false
    )

    private val tabs = mutableListOf<BrowserTab>()
    private var currentIndex = -1
    private var detectedVideoUrl: String? = null
    private val prefs by lazy { getSharedPreferences("xm_prefs", MODE_PRIVATE) }

    // ── Lifecycle ──────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        applyDarkMode()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bookmarkManager = BookmarkManager(this)
        initRuntime()
        bindViews()
        setupListeners()
        newTab(HOME_URL)
    }

    private fun applyDarkMode() {
        val dark = getSharedPreferences("xm_prefs", MODE_PRIVATE).getBoolean("dark", false)
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun initRuntime() {
        // ─── تنظیمات موتور Firefox ────────────────────────────
        val settings = GeckoRuntimeSettings.Builder()
            // مسدود کردن تبلیغات و تراکرها در سطح موتور
            .contentBlocking(
                ContentBlocking.Settings.Builder()
                    .enhancedTrackingProtection(ContentBlocking.EtpLevel.STRICT)
                    .antiTracking(
                        ContentBlocking.AntiTracking.AD or
                        ContentBlocking.AntiTracking.ANALYTIC or
                        ContentBlocking.AntiTracking.SOCIAL or
                        ContentBlocking.AntiTracking.FINGERPRINTING or
                        ContentBlocking.AntiTracking.ALL
                    )
                    .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                    .build()
            )
            .javaScriptEnabled(true)
            .remoteDebuggingEnabled(false)
            .build()

        runtime = GeckoRuntime.create(this, settings)
    }

    // ── Tab Management ─────────────────────────────────────────
    private fun newTab(url: String) {
        val session = GeckoSession()
        val geckoView = GeckoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val tab = BrowserTab(session, geckoView)
        tabs.add(tab)
        geckoContainer.addView(geckoView)

        // ─── تنظیمات Session ───────────────────────────────
        session.settings.apply {
            useTrackingProtection = true
            allowJavascript = true
        }

        // ─── Navigation Delegate ────────────────────────────
        session.navigationDelegate = object : NavigationDelegate {
            override fun onLocationChange(s: GeckoSession, u: String?, perms: List<ContentPermission>) {
                tab.url = u ?: ""
                if (isCurrentTab(tab)) runOnUiThread { addressBar.setText(u) }
            }
            override fun onCanGoBack(s: GeckoSession, canGoBack: Boolean) {
                tab.canGoBack = canGoBack
                if (isCurrentTab(tab)) runOnUiThread { btnBack.isEnabled = canGoBack }
            }
            override fun onCanGoForward(s: GeckoSession, canGoForward: Boolean) {
                tab.canGoForward = canGoForward
                if (isCurrentTab(tab)) runOnUiThread { btnForward.isEnabled = canGoForward }
            }
            // جلوگیری از ریدایرکت‌های ناخواسته
            override fun onLoadRequest(
                s: GeckoSession, req: NavigationDelegate.LoadRequest
            ): GeckoResult<NavigationDelegate.AllowOrDeny>? {
                val url = req.uri
                if (AdBlocker.shouldBlock(url)) {
                    return GeckoResult.fromValue(NavigationDelegate.AllowOrDeny.DENY)
                }
                if (VideoDetector.isVideoUrl(url)) {
                    runOnUiThread { showVideoButton(url) }
                }
                return GeckoResult.fromValue(NavigationDelegate.AllowOrDeny.ALLOW)
            }
            // مسدود کردن پاپ‌آپ
            override fun onNewSession(
                s: GeckoSession, uri: String
            ): GeckoResult<GeckoSession>? = null // null = رد کردن پاپ‌آپ
        }

        // ─── Content Delegate ───────────────────────────────
        session.contentDelegate = object : ContentDelegate {
            override fun onTitleChange(s: GeckoSession, title: String?) {
                tab.title = title ?: tab.url
            }
            // دانلود فایل‌ها
            override fun onExternalResponse(s: GeckoSession, resp: WebResponse) {
                val url = resp.uri
                val mime = resp.headers["content-type"] ?: ""
                if (VideoDetector.isVideoUrl(url, mime)) {
                    runOnUiThread { showVideoButton(url) }
                } else {
                    val name = url.substringBefore("?").substringAfterLast("/")
                        .ifBlank { "file_${System.currentTimeMillis()}" }
                    DownloadHelper.download(this@MainActivity, url, name, null)
                }
            }
        }

        // ─── Progress Delegate ──────────────────────────────
        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onProgressChange(s: GeckoSession, progress: Int) {
                if (isCurrentTab(tab)) runOnUiThread {
                    progressBar.progress = progress
                    progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
                    detectedVideoUrl = null
                    btnDownloadVideo.visibility = View.GONE
                }
            }
            override fun onPageStart(s: GeckoSession, url: String) {
                if (isCurrentTab(tab)) runOnUiThread {
                    addressBar.setText(url)
                    detectedVideoUrl = null
                    btnDownloadVideo.visibility = View.GONE
                }
            }
        }

        session.open(runtime)
        geckoView.setSession(session)
        session.loadUri(url)
        switchToTab(tabs.size - 1)
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        currentIndex = index
        for (i in tabs.indices) {
            tabs[i].view.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        val tab = tabs[index]
        addressBar.setText(tab.url)
        btnBack.isEnabled    = tab.canGoBack
        btnForward.isEnabled = tab.canGoForward
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        tabs[index].session.close()
        geckoContainer.removeView(tabs[index].view)
        tabs.removeAt(index)
        if (tabs.isEmpty()) newTab(HOME_URL)
        else switchToTab(if (index >= tabs.size) tabs.size - 1 else index)
    }

    private fun isCurrentTab(tab: BrowserTab) = tabs.getOrNull(currentIndex) === tab
    private fun currentSession() = tabs.getOrNull(currentIndex)?.session

    // ── UI ─────────────────────────────────────────────────────
    private fun bindViews() {
        geckoContainer    = findViewById(R.id.webViewContainer)
        addressBar        = findViewById(R.id.addressBar)
        progressBar       = findViewById(R.id.progressBar)
        btnBack           = findViewById(R.id.btnBack)
        btnForward        = findViewById(R.id.btnForward)
        btnRefresh        = findViewById(R.id.btnRefresh)
        btnHome           = findViewById(R.id.btnHome)
        btnBookmarks      = findViewById(R.id.btnBookmarks)
        btnTabs           = findViewById(R.id.btnTabs)
        btnNewTab         = findViewById(R.id.btnNewTab)
        btnDarkMode       = findViewById(R.id.btnDarkMode)
        btnDownloadVideo  = findViewById(R.id.btnDownloadVideo)
        tvStatus          = findViewById(R.id.tvAdBlockStatus)
        tvStatus.text     = "🛡 محافظت فعال"
        tvStatus.visibility = View.VISIBLE
    }

    private fun setupListeners() {
        addressBar.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO || id == EditorInfo.IME_ACTION_DONE) {
                loadInput(addressBar.text.toString()); true
            } else false
        }
        btnBack.setOnClickListener    { currentSession()?.goBack() }
        btnForward.setOnClickListener { currentSession()?.goForward() }
        btnRefresh.setOnClickListener { currentSession()?.reload() }
        btnHome.setOnClickListener    { currentSession()?.loadUri(HOME_URL) }
        btnBookmarks.setOnClickListener { showBookmarksDialog() }
        btnTabs.setOnClickListener      { showTabsDialog() }
        btnNewTab.setOnClickListener    { newTab(HOME_URL) }
        btnDarkMode.setOnClickListener  { toggleDark() }
        btnDownloadVideo.setOnClickListener { downloadVideo() }
    }

    private fun loadInput(input: String) {
        val t = input.trim()
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            Patterns.WEB_URL.matcher(t).matches() && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=${Uri.encode(t)}"
        }
        currentSession()?.loadUri(url)
    }

    private fun showVideoButton(url: String) {
        detectedVideoUrl = url
        runOnUiThread { btnDownloadVideo.visibility = View.VISIBLE }
    }

    private fun downloadVideo() {
        val url = detectedVideoUrl ?: return
        val name = VideoDetector.getFileName(url)
        DownloadHelper.download(this, url, name, null)
    }

    private fun toggleDark() {
        val isDark = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putBoolean("dark", !isDark).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        )
        recreate()
    }

    private fun showBookmarksDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        view.findViewById<TextView>(R.id.dialogTitle).text = getString(R.string.bookmarks)
        val rv    = view.findViewById<RecyclerView>(R.id.dialogList)
        val empty = view.findViewById<TextView>(R.id.dialogEmpty)
        val btn   = view.findViewById<Button>(R.id.dialogActionButton).apply {
            visibility = View.VISIBLE; text = getString(R.string.add_current_page)
        }
        val dialog = AlertDialog.Builder(this).setView(view).create()
        fun refresh() {
            val list = bookmarkManager.getAll()
            empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            rv.layoutManager = LinearLayoutManager(this)
            rv.adapter = BookmarkAdapter(list,
                onOpen   = { currentSession()?.loadUri(it.url); dialog.dismiss() },
                onDelete = { bookmarkManager.remove(it.url); refresh() })
        }
        btn.setOnClickListener {
            tabs.getOrNull(currentIndex)?.let {
                if (it.url.isNotBlank()) { bookmarkManager.add(it.title, it.url); refresh() }
            }
        }
        refresh(); dialog.show()
    }

    private fun showTabsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        view.findViewById<TextView>(R.id.dialogTitle).text = getString(R.string.tabs)
        view.findViewById<TextView>(R.id.dialogEmpty).visibility = View.GONE
        val rv  = view.findViewById<RecyclerView>(R.id.dialogList)
        val btn = view.findViewById<Button>(R.id.dialogActionButton).apply {
            visibility = View.VISIBLE; text = getString(R.string.new_tab)
        }
        val dialog = AlertDialog.Builder(this).setView(view).create()

        // تبدیل BrowserTab به Tab برای آداپتور
        val fakeTabs = tabs.map { Tab(it.view as android.webkit.WebView? ?: android.webkit.WebView(this), it.title, it.url) }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = TabAdapter(fakeTabs,
            onSelect = { switchToTab(it); dialog.dismiss() },
            onClose  = { closeTab(it); rv.adapter?.notifyDataSetChanged(); if (tabs.isEmpty()) dialog.dismiss() })
        btn.setOnClickListener { newTab(HOME_URL); dialog.dismiss() }
        dialog.show()
    }

    override fun onBackPressed() {
        val tab = tabs.getOrNull(currentIndex)
        if (tab?.canGoBack == true) currentSession()?.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.session.close() }
        runtime.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val HOME_URL = "file:///android_asset/home.html"
    }
}
