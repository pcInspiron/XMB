package com.xm.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String)

class BookmarkManager(context: Context) {

    private val prefs = context.getSharedPreferences("xm_browser_prefs", Context.MODE_PRIVATE)
    private val KEY = "bookmarks"

    fun getAll(): MutableList<Bookmark> {
        val list = mutableListOf<Bookmark>()
        val json = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(Bookmark(obj.getString("title"), obj.getString("url")))
        }
        return list
    }

    fun add(title: String, url: String) {
        val list = getAll()
        if (list.any { it.url == url }) return
        list.add(0, Bookmark(title, url))
        save(list)
    }

    fun remove(url: String) {
        val list = getAll().filterNot { it.url == url }.toMutableList()
        save(list)
    }

    fun isBookmarked(url: String): Boolean = getAll().any { it.url == url }

    private fun save(list: List<Bookmark>) {
        val arr = JSONArray()
        for (b in list) {
            val obj = JSONObject()
            obj.put("title", b.title)
            obj.put("url", b.url)
            arr.put(obj)
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
