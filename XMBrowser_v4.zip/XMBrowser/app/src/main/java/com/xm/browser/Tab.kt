package com.xm.browser

import android.webkit.WebView

// این کلاس فقط برای سازگاری آداپتور نگه داشته شده
data class Tab(
    val webView: WebView,
    var title: String = "تب جدید",
    var url: String = ""
)
