package com.xm.browser

object AdBlocker {

    private val BLOCKED_DOMAINS = setOf(
        "doubleclick.net","googlesyndication.com","googleadservices.com",
        "adnxs.com","adsrvr.org","rubiconproject.com","openx.net",
        "pubmatic.com","criteo.com","taboola.com","outbrain.com",
        "revcontent.com","sharethrough.com","smartadserver.com",
        "advertising.com","media.net","popcash.net","popads.net",
        "adcash.com","trafficjunky.net","exoclick.com","adsterra.com",
        "propellerads.com","yektanet.com","clickyab.com","chadnet.ir",
        "zedo.com","bidvertiser.com","adservice.google.com",
        "pagead2.googlesyndication.com","tpc.googlesyndication.com",
        "hotjar.com","clarity.ms","fullstory.com","mixpanel.com",
        "cdn.taboola.com","trc.taboola.com","cdn.outbrain.com",
        "widgets.outbrain.com","log.outbrain.com","amplify.outbrain.com"
    )

    private val BLOCKED_PATHS = listOf(
        "/pagead/", "/ads/ga-audiences", "/adview", "/ads?",
        "/banner/", "/popup/", "/tracking/", "/_ads/",
        "/ad.php", "/adserver/", "/click.php", "/impression"
    )

    fun shouldBlock(url: String): Boolean {
        val lower = url.lowercase()
        for (domain in BLOCKED_DOMAINS) {
            if (lower.contains(domain)) return true
        }
        for (path in BLOCKED_PATHS) {
            if (lower.contains(path)) return true
        }
        return false
    }

    // CSS برای مخفی کردن تبلیغات در DOM صفحه
    val ADBLOCK_CSS = """
        (function() {
            var style = document.createElement('style');
            style.textContent = `
                ins.adsbygoogle, [id*='google_ads'], [id*='div-gpt-ad'],
                [class*='ad-container'], [class*='ad-wrapper'],
                [class*='ads-container'], [id*='ads-container'],
                [class*='advertisement'], [id*='advertisement'],
                [class*='banner-ad'], [id*='banner-ad'],
                .ytp-ad-overlay-container, .ytp-ad-text-overlay,
                #masthead-ad, ytd-banner-promo-renderer,
                ytd-ad-slot-renderer, ytd-promoted-sparkles-web-renderer,
                ytd-promoted-video-renderer, .ytd-display-ad-renderer,
                [class*='popup'], [id*='popup'], .overlay-ad,
                [class*='interstitial'], .ad-notice, #aswift_,
                iframe[id*='aswift'], iframe[src*='googlesyndication'],
                iframe[src*='doubleclick'], div[aria-label='Ads'],
                .taboola-widget, #taboola-, .outbrain-widget
                { display: none !important; visibility: hidden !important; }
            `;
            document.head && document.head.appendChild(style);
        })();
    """.trimIndent()

    // JS مخصوص یوتیوب برای رد کردن تبلیغ
    val YOUTUBE_SKIP_JS = """
        (function() {
            var skipAd = function() {
                var btn = document.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button');
                if (btn) { btn.click(); return; }
                var video = document.querySelector('video');
                var adBadge = document.querySelector('.ytp-ad-badge, .ad-showing');
                if (video && adBadge) { video.currentTime = video.duration; }
            };
            setInterval(skipAd, 500);
        })();
    """.trimIndent()
}
