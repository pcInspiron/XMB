package com.xm.browser

object VideoDetector {

    private val VIDEO_EXTENSIONS = listOf(
        ".mp4", ".m3u8", ".webm", ".mkv", ".avi", ".mov",
        ".flv", ".ts", ".mpd", ".m4v", ".3gp"
    )

    private val VIDEO_DOMAINS = listOf(
        "googlevideo.com", "youtube.com/videoplayback",
        "cdninstagram.com", "video.twimg.com",
        "fbcdn.net", "dailymotion.com/video",
        "vimeocdn.com", "akamaihd.net"
    )

    private val VIDEO_MIME_TYPES = listOf(
        "video/mp4", "video/webm", "video/x-matroska",
        "video/quicktime", "application/x-mpegURL",
        "application/vnd.apple.mpegurl", "video/MP2T"
    )

    fun isVideoUrl(url: String, mimeType: String? = null): Boolean {
        val lower = url.lowercase()

        // بررسی mime type
        if (mimeType != null) {
            for (mime in VIDEO_MIME_TYPES) {
                if (mimeType.contains(mime, ignoreCase = true)) return true
            }
        }

        // بررسی پسوند فایل
        for (ext in VIDEO_EXTENSIONS) {
            if (lower.contains(ext)) return true
        }

        // بررسی دامنه‌های شناخته‌شده
        for (domain in VIDEO_DOMAINS) {
            if (lower.contains(domain)) return true
        }

        return false
    }

    fun getFileName(url: String): String {
        return try {
            val path = url.substringBefore("?").substringAfterLast("/")
            if (path.isNotBlank() && path.contains(".")) path
            else "video_${System.currentTimeMillis()}.mp4"
        } catch (e: Exception) {
            "video_${System.currentTimeMillis()}.mp4"
        }
    }
}
