package com.xm.browser

object AdBlocker {

    private val BLOCKED_DOMAINS = setOf(
        // شبکه‌های تبلیغاتی اصلی
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adnxs.com", "adsrvr.org", "rubiconproject.com", "openx.net",
        "pubmatic.com", "criteo.com", "taboola.com", "outbrain.com",
        "revcontent.com", "sharethrough.com", "smartadserver.com",
        "advertising.com", "ads.yahoo.com", "media.net",
        // تراکرها
        "google-analytics.com", "googletagmanager.com", "googletagservices.com",
        "analytics.google.com", "hotjar.com", "mixpanel.com", "segment.com",
        "amplitude.com", "fullstory.com", "clarity.ms",
        // پاپ‌آپ و ریدایرکت
        "popcash.net", "popads.net", "pop.sh", "adcash.com",
        "trafficjunky.net", "exoclick.com", "juicyads.com", "trafficstars.com",
        "adsterra.com", "propellerads.com", "hilltopads.net",
        // تبلیغات ایرانی
        "yektanet.com", "adservice.ir", "ads.ir", "iradnet.com",
        "clickyab.com", "chadnet.ir", "inmobi.com",
        // اسپای‌ور و مالور
        "zedo.com", "adbrite.com", "kontera.com", "buysellads.com",
        "bidvertiser.com", "chitika.com",
        // CDN تبلیغاتی
        "cdn.adnxs.com", "secure.adnxs.com", "static.criteo.net",
        "cdn.taboola.com", "trc.taboola.com"
    )

    private val BLOCKED_KEYWORDS = listOf(
        "/ads/", "/ad/", "/adserver/", "/adservice/", "/advertisement/",
        "/banner/", "/popup/", "/popunder/", "/tracking/", "/tracker/",
        "adclick", "adsense", "adwords", "googlead", "/pagead/",
        "click.php?", "track.php?", "impression?"
    )

    fun shouldBlock(url: String): Boolean {
        val lower = url.lowercase()
        // بررسی دامنه‌ها
        for (domain in BLOCKED_DOMAINS) {
            if (lower.contains(domain)) return true
        }
        // بررسی کلمات کلیدی در URL
        for (keyword in BLOCKED_KEYWORDS) {
            if (lower.contains(keyword)) return true
        }
        return false
    }
}
