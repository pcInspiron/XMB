package com.xm.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private lateinit var webViewContainer: FrameLayout
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnBookmarks: ImageButton
    private lateinit var btnTabs: ImageButton
    private lateinit var btnNewTab: ImageButton
    private lateinit var btnDarkMode: ImageButton
    private lateinit var btnDownloadVideo: ImageButton

    private lateinit var bookmarkManager: BookmarkManager
    private val tabs = mutableListOf<Tab>()
    private var currentTabIndex = -1
    private var detectedVideoUrl: String? = null

    private val prefs by lazy { getSharedPreferences("xm_browser_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        val isDark = getSharedPreferences("xm_browser_prefs", MODE_PRIVATE)
            .getBoolean("dark_mode", false)
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bookmarkManager = BookmarkManager(this)
        bindViews()
        setupListeners()
        createNewTab(HOME_URL)
    }

    private fun bindViews() {
        webViewContainer = findViewById(R.id.webViewContainer)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnBookmarks = findViewById(R.id.btnBookmarks)
        btnTabs = findViewById(R.id.btnTabs)
        btnNewTab = findViewById(R.id.btnNewTab)
        btnDarkMode = findViewById(R.id.btnDarkMode)
        btnDownloadVideo = findViewById(R.id.btnDownloadVideo)
    }

    private fun setupListeners() {
        addressBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                loadInput(addressBar.text.toString()); true
            } else false
        }
        btnBack.setOnClickListener { currentWebView()?.let { if (it.canGoBack()) it.goBack() } }
        btnForward.setOnClickListener { currentWebView()?.let { if (it.canGoForward()) it.goForward() } }
        btnRefresh.setOnClickListener { currentWebView()?.reload() }
        btnHome.setOnClickListener { currentWebView()?.loadUrl(HOME_URL) }
        btnBookmarks.setOnClickListener { showBookmarksDialog() }
        btnTabs.setOnClickListener { showTabsDialog() }
        btnNewTab.setOnClickListener { createNewTab(HOME_URL) }
        btnDarkMode.setOnClickListener { toggleDarkMode() }
        btnDownloadVideo.setOnClickListener { downloadDetectedVideo() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createNewTab(url: String) {
        val webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        configureWebView(webView)

        val tab = Tab(webView)
        tabs.add(tab)
        webViewContainer.addView(webView)

        webView.webViewClient = object : WebViewClient() {

            // ─── AdBlock: مسدود کردن تبلیغات ───
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                if (AdBlocker.shouldBlock(url)) {
                    return WebResourceResponse("text/plain", "utf-8", null)
                }
                // تشخیص ویدیو
                if (VideoDetector.isVideoUrl(url)) {
                    runOnUiThread { showVideoButton(url) }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val u = request.url.toString()
                if (!u.startsWith("http://") && !u.startsWith("https://")) {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, request.url)); true }
                    catch (e: Exception) { true }
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                // مخفی کردن دکمه ویدیو هنگام بارگذاری صفحه جدید
                runOnUiThread {
                    detectedVideoUrl = null
                    btnDownloadVideo.visibility = View.GONE
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                tab.url = url
                tab.title = view.title ?: url
                if (isCurrentTab(tab)) {
                    addressBar.setText(url)
                    updateNavButtons()
                }
                // تزریق JS برای مسدود کردن پاپ‌آپ‌ها
                view.evaluateJavascript(POPUP_BLOCK_JS, null)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (isCurrentTab(tab)) {
                    progressBar.progress = newProgress
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
            override fun onReceivedTitle(view: WebView, title: String?) {
                tab.title = title ?: tab.url
            }
            // مسدود کردن پاپ‌آپ
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
            ) = false
        }

        // دانلود مستقیم فایل‌ها
        webView.setDownloadListener { url, userAgent, _, mimeType, _ ->
            if (VideoDetector.isVideoUrl(url, mimeType)) {
                showVideoButton(url)
            } else {
                val fileName = url.substringBefore("?").substringAfterLast("/")
                    .ifBlank { "file_${System.currentTimeMillis()}" }
                DownloadHelper.download(this, url, fileName, userAgent)
            }
        }

        webView.loadUrl(url)
        switchToTab(tabs.size - 1)
    }

    private fun showVideoButton(url: String) {
        detectedVideoUrl = url
        btnDownloadVideo.visibility = View.VISIBLE
    }

    private fun downloadDetectedVideo() {
        val url = detectedVideoUrl ?: return
        val fileName = VideoDetector.getFileName(url)
        DownloadHelper.download(this, url, fileName,
            currentWebView()?.settings?.userAgentString)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.javaScriptCanOpenWindowsAutomatically = false  // جلوگیری از پاپ‌آپ JS
        applyWebViewDarkMode(webView)
    }

    private fun applyWebViewDarkMode(webView: WebView) {
        val isDark = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, isDark)
        }
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        for (i in tabs.indices) {
            tabs[i].webView.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        val tab = tabs[index]
        addressBar.setText(tab.url)
        updateNavButtons()
        // وضعیت دکمه ویدیو
        btnDownloadVideo.visibility = if (detectedVideoUrl != null) View.VISIBLE else View.GONE
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        webViewContainer.removeView(tab.webView)
        tab.webView.destroy()
        tabs.removeAt(index)
        if (tabs.isEmpty()) createNewTab(HOME_URL)
        else switchToTab(if (index >= tabs.size) tabs.size - 1 else index)
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(currentTabIndex)?.webView
    private fun isCurrentTab(tab: Tab): Boolean = tabs.getOrNull(currentTabIndex) === tab

    private fun updateNavButtons() {
        val wv = currentWebView()
        btnBack.isEnabled = wv?.canGoBack() ?: false
        btnForward.isEnabled = wv?.canGoForward() ?: false
    }

    private fun loadInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return
        val url = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${Uri.encode(trimmed)}"
        }
        currentWebView()?.loadUrl(url)
    }

    private fun toggleDarkMode() {
        val isDark = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putBoolean("dark_mode", !isDark).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        )
        recreate()
    }

    private fun showBookmarksDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        view.findViewById<TextView>(R.id.dialogTitle).text = getString(R.string.bookmarks)
        val recyclerView = view.findViewById<RecyclerView>(R.id.dialogList)
        val emptyView = view.findViewById<TextView>(R.id.dialogEmpty)
        val addButton = view.findViewById<Button>(R.id.dialogActionButton).apply {
            visibility = View.VISIBLE
            text = getString(R.string.add_current_page)
        }
        val dialog = AlertDialog.Builder(this).setView(view).create()

        fun refresh() {
            val bookmarks = bookmarkManager.getAll()
            emptyView.visibility = if (bookmarks.isEmpty()) View.VISIBLE else View.GONE
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = BookmarkAdapter(bookmarks,
                onOpen = { currentWebView()?.loadUrl(it.url); dialog.dismiss() },
                onDelete = { bookmarkManager.remove(it.url); refresh() })
        }

        addButton.setOnClickListener {
            tabs.getOrNull(currentTabIndex)?.let {
                if (it.url.isNotBlank()) { bookmarkManager.add(it.title.ifBlank { it.url }, it.url); refresh() }
            }
        }
        refresh()
        dialog.show()
    }

    private fun showTabsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        view.findViewById<TextView>(R.id.dialogTitle).text = getString(R.string.tabs)
        view.findViewById<TextView>(R.id.dialogEmpty).visibility = View.GONE
        val recyclerView = view.findViewById<RecyclerView>(R.id.dialogList)
        val addButton = view.findViewById<Button>(R.id.dialogActionButton).apply {
            visibility = View.VISIBLE
            text = getString(R.string.new_tab)
        }
        val dialog = AlertDialog.Builder(this).setView(view).create()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = TabAdapter(tabs,
            onSelect = { switchToTab(it); dialog.dismiss() },
            onClose = { closeTab(it); recyclerView.adapter?.notifyDataSetChanged(); if (tabs.isEmpty()) dialog.dismiss() })
        addButton.setOnClickListener { createNewTab(HOME_URL); dialog.dismiss() }
        dialog.show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val wv = currentWebView()
        if (wv != null && wv.canGoBack()) wv.goBack() else super.onBackPressed()
    }

    companion object {
        private const val HOME_URL = "file:///android_asset/home.html"

        // جاوااسکریپت برای مسدود کردن پاپ‌آپ و تبلیغات در DOM
        private const val POPUP_BLOCK_JS = """
            (function() {
                // مسدود کردن window.open
                window.open = function() { return null; };
                // حذف المان‌های تبلیغاتی رایج
                var selectors = [
                    '[id*="ad"]','[class*="ad-"]','[class*="ads-"]',
                    '[id*="popup"]','[class*="popup"]','[class*="overlay"]',
                    'iframe[src*="ad"]','ins.adsbygoogle',
                    '[class*="banner"]','[id*="banner"]'
                ];
                selectors.forEach(function(sel) {
                    document.querySelectorAll(sel).forEach(function(el) {
                        if (el.offsetHeight > 0) el.style.display = 'none';
                    });
                });
            })();
        """
    }
}
